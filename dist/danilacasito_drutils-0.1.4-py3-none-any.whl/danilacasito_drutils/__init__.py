"""
drutils.

My Multi Use Python Package
"""

__version__ = "0.1.4"
__author__ = "danilacasito"
__credits__ = "Only me, i'm the only who maintains this"
import drutils.parse
