"""
drutils.

My Multi Use Python Package
"""

__version__ = "0.1.7"
__author__ = "danilacasito"
__credits__ = "Only me, i'm the only who maintains this"
import danilacasito_drutils.parse
import danilacasito_drutils.network